# MCHAT Android prototype

This is the first Android UI prototype for MCHAT.

## Current prototype
- Dark teal modern chat list
- Search conversations
- Open a conversation and send local demo messages
- GitHub Actions workflow to build a debug APK

## Important limitations
This first APK is only a local UI prototype. Messages do **not** reach another phone yet. Supabase, user registration, real-time delivery, push notifications, media sharing, voice/video calls, and end-to-end encryption are not connected yet.

## Build APK using GitHub Actions
1. Upload all files in this project to a GitHub repository on the `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build MCHAT APK** and press **Run workflow**, or push a commit.
4. Open the completed workflow run and download the `MCHAT-debug-apk` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on Android.

The workflow uses Gradle installed in GitHub Actions, so a Gradle wrapper is not required in this ZIP.
